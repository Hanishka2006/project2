import pandas as pd
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans

# Load dataset from Excel file
df = pd.read_excel('spotify_songs1.xlsx')  # Make sure the file name is correct

# Display the first few rows to ensure the file is loaded correctly
print("Data Loaded Successfully")
print(df.head())

# Data Pre-processing
# Select relevant features
features = ['danceability', 'energy', 'valence', 'tempo', 'loudness', 'speechiness', 'acousticness', 'instrumentalness', 'liveness']

# Handle missing values (if any)
df.dropna(subset=features, inplace=True)

# Normalize the features
scaler = StandardScaler()
df[features] = scaler.fit_transform(df[features])

print("Data Pre-processing Completed")

# Data Analysis and Visualizations
# Visualize feature distributions
for feature in features:
    plt.figure(figsize=(10, 6))
    sns.histplot(df[feature], kde=True)
    plt.title(f'Distribution of {feature}')
    plt.show()

# Correlation Matrix
# Compute and plot the correlation matrix
correlation_matrix = df[features].corr()

plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Correlation Matrix')
plt.show()

# Clustering
# Determine optimal number of clusters using Elbow Method
inertia = []
for n in range(1, 15):
    kmeans = KMeans(n_clusters=n, random_state=42)
    kmeans.fit(df[features])
    inertia.append(kmeans.inertia_)

plt.plot(range(1, 15), inertia)
plt.xlabel('Number of Clusters')
plt.ylabel('Inertia')
plt.title('Elbow Method to Determine Optimal Clusters')
plt.show()

# Train the KMeans model
optimal_clusters = 5  # Adjust based on your elbow method result
kmeans = KMeans(n_clusters=optimal_clusters, random_state=42)
df['cluster'] = kmeans.fit_predict(df[features])

# Plot clusters with genres
plt.figure(figsize=(12, 8))
sns.scatterplot(data=df, x='tempo', y='danceability', hue='cluster', palette='viridis')
plt.title('Clusters by Tempo and Danceability')
plt.show()

# Final clustered dataset
print(df.head())

# Save the clustered data for the recommendation system
df.to_csv('clustered_spotify_songs.csv', index=False)

print("Model building and clustering completed. Data saved for recommendation system.")
